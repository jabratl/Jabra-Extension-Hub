# Jabra Extension API v1 — Compatibility Contract

This document defines the supported host API for extensions running in Jabra Extension Hub. Do not assume that the host is a Capacitor app, Chrome extension runtime, or ordinary desktop browser.

## Compatibility rules

1. Feature-detect every native API at runtime. Never assume a method exists just because another extension used it.
2. Read `JabraAPI.info()` and/or `JabraAPI.capabilities()` before relying on optional features.
3. Keep browser fallbacks where safe. If no safe fallback exists, show a clear unsupported-feature message; do not silently claim success.
4. Keep import and export separate and test both. Also test share, backup restore, malformed files, cancel actions, and large files.
5. Do not depend on Capacitor APIs (`Capacitor`, `Filesystem`, `Share`) unless the extension explicitly targets a separate Capacitor host.
6. Do not use `file://` URLs or arbitrary local paths. Use the host file API, a user-selected file, or a `content://` URI managed by Android.
7. Never overwrite or delete user data during import without explicit confirmation. Validate backups before changing current data.
8. Store extension data only under its own scoped keys. Do not attempt to read another extension's private storage.
9. Keep extension manifests backward-compatible. Unknown optional fields may be ignored; unknown required permissions/features must be handled explicitly by the host.

## API v1 methods currently provided by the Hub

| Method | Contract | Notes |
|---|---|---|
| `info()` | Returns JSON text describing host version, API version, capabilities and limitations | Parse with `JSON.parse` inside `try/catch`; legacy v1 boolean fields remain available |
| `capabilities()` | Returns a JSON array as text | Feature detection; do not rely only on version strings |
| `storageGet(key)` | Returns string or null | Per-extension private storage |
| `storageSet(key, value)` | Returns boolean | Keep values reasonably sized; check result |
| `storageRemove(key)` | Returns boolean | Scoped to current extension |
| `storageKeys(prefix)` | Returns JSON array text | Prefix-filtered keys for current extension |
| `storageRemovePrefix(prefix)` | Returns boolean | Destructive; use only for your own namespace |
| `getItem(key)` / `setItem(key,value)` / `removeItem(key)` | Legacy simple settings API | Prefer `storage*` for new extensions |
| `exportBase64File(name, base64, mime)` | Returns boolean | Saves generated data to Downloads on supported Android versions; check result |
| `shareBase64File(name, base64, mime)` | Returns boolean | Opens Android Sharesheet with a content URI; user still chooses destination |
| `copyText(text)` | Returns whether request was accepted | Clipboard work happens on Android main thread; a true return does not guarantee the user kept the clipboard contents |
| `shareText(text, title)` | Returns whether request was accepted | Opens system Sharesheet |
| `toast(message)` | Shows short Android message | Optional convenience only |
| `recordDiagnostic(event, detail)` | Returns boolean; appends a bounded, local-only diagnostic entry | Do not log passwords, tokens, personal content, or full documents; the user must choose to share logs |
| `JabraCompat.storageGet/Set/Remove` | Helper wrappers around native scoped storage with safe browser fallback | Helper functions, not direct bridge methods; check return values |

`info()` also returns `hostVersion`, `hostPackage`, `androidApiLevel`, `minSupportedApiVersion`, and a `limitations` array. The earlier v1 fields `durableStorage`, `fileExport`, `fileShare`, `clipboardWrite`, and `textShare` are retained for backward compatibility.
| HTML `<input type="file">` | Opens Android document picker through the WebView file chooser | Use FileReader to read the selected file; handle cancel/error |

## Capability names currently advertised by API v1

`storage`, `fileExport`, `fileShare`, `fileImportPicker`, `clipboardWrite`, `textShare`, `toast`, `diagnostics`, and `apiVersionInfo`.

The list is a compatibility contract, not a promise that every operation succeeds under every device condition. Check method presence, check boolean results, and handle cancellation, unavailable handlers, storage failures, and share-sheet failures.

## File export fallback pattern

```js
async function blobToBase64(blob) {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(reader.error || new Error('Could not read export data'));
    reader.readAsDataURL(blob);
  });
}

async function saveBlob(name, blob) {
  const api = window.JabraAPI;
  if (api && typeof api.exportBase64File === 'function') {
    const ok = api.exportBase64File(name, await blobToBase64(blob), blob.type || 'application/octet-stream');
    if (!ok) throw new Error('Hub export failed; try again or use Share as an alternative.');
    return { ok: true, method: 'hub-export' };
  }
  // Browser fallback: not guaranteed in every embedded WebView.
  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    return { ok: true, method: 'browser-download', fallbackMayVary: true };
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
}
```

## Share fallback pattern

```js
async function shareBlob(name, blob) {
  const api = window.JabraAPI;
  if (api && typeof api.shareBase64File === 'function') {
    const ok = api.shareBase64File(name, await blobToBase64(blob), blob.type || 'application/octet-stream');
    if (!ok) throw new Error('Hub share failed; use Export instead.');
    return { ok: true, method: 'hub-share' };
  }
  const file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
  if (navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
    await navigator.share({ files: [file], title: name });
    return { ok: true, method: 'web-share' };
  }
  return await saveBlob(name, blob);
}
```

## Import pattern

Use `<input type="file" accept=".json,application/json">`, then `FileReader` to read the file. Validate its schema, version, required fields and reasonable size before showing a preview. Do not replace live data until validation succeeds and the user confirms. Provide merge and replace as clearly separate actions when appropriate.

## Manifest compatibility metadata

The following optional fields are supported by the Hub:

```json
{
  "id": "example-plugin",
  "name": "Example Plugin",
  "version": "1.0.0",
  "entry": "index.html",
  "minJabraApiVersion": 1,
  "requiredCapabilities": ["storage", "apiVersionInfo"]
}
```

- If `minJabraApiVersion` is absent, it defaults to `1` for compatibility with existing plugins.
- If the minimum API version is newer than the installed Hub, installation is rejected before the existing plugin is replaced.
- `requiredCapabilities` must be an array of capability names supported by the Hub. Unknown required capabilities cause a clear install error instead of a plugin failing later at runtime.
- Optional capabilities should not be declared as required; feature-detect them at runtime.
- These fields are compatibility metadata, not a security permission system. Installed plugin JavaScript is still code and should come from a trusted source.

## Capability detection

```js
function getJabraHostInfo() {
  try {
    if (!window.JabraAPI || typeof JabraAPI.info !== 'function') return null;
    return JSON.parse(JabraAPI.info());
  } catch (_) {
    return null;
  }
}
function hasJabraCapability(name) {
  const info = getJabraHostInfo();
  return !!(info && Array.isArray(info.capabilities) && info.capabilities.includes(name));
}
```

## Not part of API v1 yet

These must not be assumed to exist: background execution, scheduled jobs, arbitrary URL downloads, push notifications, cloud sync, file-system browsing without user selection, cross-extension messaging, arbitrary clipboard read, Chrome `chrome.*` APIs, service workers as a Chrome extension runtime, and privileged access to other apps. Add them only through a documented API version/capability with explicit permission and tests.

## Release acceptance tests for every extension

- Install and launch from a clean state.
- Test on the Hub's minimum supported Android version and a current Android version when available.
- Test storage write/read after app restart.
- Test import valid, invalid, oversized, and cancelled files.
- Test export, share, and restore independently.
- Test missing optional API and browser fallback.
- Confirm a plugin requiring API v2 is rejected by API v1 without changing an existing installation.
- Confirm an unknown required capability is rejected before install.
- Confirm `recordDiagnostic` writes only a local bounded entry and no automatic upload occurs.
- Test denied permissions, offline mode, and interrupted operations.
- Confirm failures are visible and never reported as success.

## Hub release 0.4.0 manager metadata

The hub accepts an optional top-level `category` field in a plugin's `manifest.json`. This is display/filter metadata only; it does not grant permissions or change the native API. If absent or unrecognized, the hub displays `Other`. Recognized values currently include `Character`, `Item`, `Skill`, `Place`, `Organization`, `Title`, `Other`, `Utility`, `Writing`, `Translation`, and `Developer`.

Favourites and manager filter/sort settings are stored by the hub in app-private preferences, separately from plugin ZIP files and plugin-owned persistent data. Removing a plugin does not automatically erase its saved plugin data; explicit erase remains a separate destructive action.


## Chapter intake (capability `chapterIntake`, Hub 0.8.0+)
- `JabraAPI.intakeGet()` returns a JSON string or null: `{title, text, source: selection|share|web|file, sourceName, mode: chapter|lookup, truncated, ts, parts?: [{title,text}]}`. When `parts` is present (EPUB), `text` is empty.
- `JabraAPI.intakeClear()` deletes the pending intake. Call it after reading.
- The Hub calls `window.__jabraIntake()` in an already-open plugin page when new text arrives. Plugins should also call `intakeGet()` at startup.
- Entry points: text-selection menu, Share sheet, Open-with for .txt/.docx/.epub/.html. Not supported: PDF, silent reading of other apps.
