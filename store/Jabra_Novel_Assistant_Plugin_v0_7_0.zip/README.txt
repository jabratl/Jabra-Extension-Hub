Jabra Novel Assistant Plugin v0.7.0

Same plugin id as before (jabra-novel-assistant), so it updates the installed v0.2.5 in place. Your novels and glossaries stay. Make a backup first (Settings > Backup > Export backup) to be safe.
Needs Jabra Extension Hub v0.8.0 or newer for Jabra Scan, as before.

Versions 0.3.0 to 0.6.0 (mode switch, target language, New project dialog, custom types and fields, tags, relationships, glossary health, glossary pack, appendix, Excel/prompt upgrades) are listed in the project CHANGELOG. This plugin includes all of them.

What is new in 0.7.0 (S7):
- GitHub sync (Settings, below Backup): your own repository, fine-grained token, one JSON file. Buttons: Test connection, Upload now, Download from GitHub. Optional automatic upload after changes (at most every 10 minutes, only when online and not during an AI run).
- Safe against two phones: remembers the version it last synced. If GitHub has a different copy, Upload asks: Cancel / Merge then upload / Replace GitHub copy. Automatic upload never overwrites; it pauses and shows a banner.
- Warns if the repository is public. Token and all GitHub settings are never written into backups or the uploaded file (API keys were already excluded).
- Backup reminder: new setting (Off / 3 days / week / 2 weeks / month). Glossary terms now count as changes, so glossary-only projects get reminders too. A GitHub upload counts as a backup. Banner offers Upload to GitHub when it is set up.
- Fixed: the New project "has chapters" checkbox and the Web AI chapter select shared id wch (since 0.3.0). Web AI chapter list did not work. The checkbox is now wizch.

Tested: JavaScript syntax; GitHub sync and the backup reminder in node against a mock GitHub. NOT tested: real GitHub from inside the Hub on a phone, the new card at 360/1280 px in light and dark.

----- Notes of earlier versions (unchanged) -----

Jabra Novel Assistant Plugin v0.2.5

Install in Jabra Extension Hub v0.8.0 or newer (needed for Jabra Scan). On older Hubs the plugin still works as before.

New:
- Incoming text panel: text sent with "Jabra Scan" from other apps opens here and is scanned against the glossary of the chosen novel.
- Shows glossary terms found (with counts), possible new names (free guess for Latin/Cyrillic/Greek text), duplicate-chapter warning.
- Actions: Full Match check, Save as chapter / English translation, Translate prompt (Web AI), Find new terms (AI), Discard.
- Short selection (up to 60 characters, one line) = quick glossary lookup with an Add-to-glossary form.
- EPUB/DOCX/TXT with several chapters: pick a chapter from a list, or save them all at once.

Tested: JavaScript syntax and a stubbed browser test of the new panel. NOT yet tested on a phone inside the real Hub.
Everything from v0.1.4 (import, backup, export/share, storage) is unchanged.

v0.2.1: added "Scan clipboard" button next to the novel selector (needs Hub 0.8.1+).

v0.2.2 (review upgrades):
- Google Translate lines: glossary names are protected, so the free draft uses your exact English names. If Google drops a name you get a warning line. Smaller chunks (fixes long Chinese lines), source language detected per line (zh/ja/ko/ru), retry with backoff, saved cache on the phone.
- Glossary > Paste text: header row now maps columns (Original / English / Type / Gender / Note in any order, tab, | or comma). Lines that could not be read are listed in a box, with a button to put them back in the box.
- Glossary > Add a term: new "Suggest (free)" button fills the English with the romanization (pinyin) and shows Google's plain translation as a draft.
- Match check > Other checks: new "Numbers to double-check" (numbers of 100 or more in the original that are missing in the translation, including Chinese numerals like 三千).

Tested: JavaScript syntax; logic tests with a mocked Google (protection, lost-name warning, cache, chunking, header mapping, unread lines, number check). NOT tested: the real Google endpoint inside the Hub on a phone (Suggest romanization depends on Google's response format).

v0.2.3:
- Fuzzy match now catches the same name written differently: Lin Feng / Lin-Feng / LinFeng, and lowercase versions of multi-part names (lin feng). Works in the quick Scan fix list and in Match check (Possible misspelling). ALL-CAPS and plain single lowercase words (e.g. sword) are not flagged.
Tested: JavaScript syntax + isolated test of the matching logic. NOT yet tested on a phone inside the Hub.

v0.2.4:
- Jabra Scan quick lookup: new "Suggest (free)" button fills the English box with the pinyin (romanization) and shows Google's plain translation as a draft.
- Match check paragraph alignment: when original and translation have a different number of paragraphs, paragraphs are now matched using glossary names as anchors (in order), instead of only by position. Used for the context shown with each term.
Tested: JavaScript syntax + isolated alignment test. NOT yet tested on a phone inside the Hub.

v0.2.5:
- Match check > Other checks: new "Quote count differs" (dialogue passages in the original vs the translation, with the paragraphs that differ when paragraph counts are equal).
- Audit and fix: new "Drift dashboard". Runs the Match check on every chapter that has an original and a translation, shows a glossary-match bar per chapter and marks chapters that got clearly worse than the previous ones. Tap a chapter to open it in Match check. Shows progress chapter by chapter.
- Match check button now shows "Running... please wait" before a big glossary is processed. (A real Web Worker was NOT added: it would need the whole engine to be moved, which is risky without testing on the phone.)
Tested: JavaScript syntax only for these three. NOT tested on a phone inside the Hub.

Still to do: native/offline translate in the Hub (needs the Hub source), real Web Worker for very big glossaries.
